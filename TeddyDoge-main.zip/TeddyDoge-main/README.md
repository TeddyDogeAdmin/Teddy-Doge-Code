#TeddyDoge

What is TeddyDoge?“One-stop full-featured decentralized exchange.”include swap, aggregate transactions,liquidity,Farm,15 mainstream chain transactions, 15 mainstream cross-chain,15 mainstream chain chart system,Token and liquidity multi-scheme locking,TeddyWallet and derivatives.

We are working hard, please look forward to it!

